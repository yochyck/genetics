/*
  app.js — Vanilla JS SPA без сборки. Открывается через index.html.
  Архитектура специально оставлена прозрачной: всё хранится в APP_DATA + localStorage.
  Для реального ИИ замените mockAIAgent()/callRealAI() на запрос к вашему backend API.
*/

(() => {
  "use strict";

  const STORAGE_KEY = window.APP_DATA.meta.storageKey;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const todayISO = () => new Date().toISOString().slice(0, 10);
  const uid = (prefix = "id") => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  const deepClone = (x) => (typeof structuredClone === "function" ? structuredClone(x) : JSON.parse(JSON.stringify(x)));

  const NAV = [
    { route: "home", label: "Главная", icon: "⌂" },
    { route: "materials", label: "Учебные материалы", icon: "📚" },
    { route: "part-1", label: "Часть 1: Мендель", icon: "Ⅰ" },
    { route: "part-2", label: "Часть 2: Человек", icon: "Ⅱ" },
    { route: "part-3", label: "Часть 3: Болезни", icon: "Ⅲ" },
    { route: "glossary", label: "Глоссарий", icon: "А" },
    { route: "classifications", label: "Классификации", icon: "≣" },
    { route: "inheritance", label: "Типы наследования", icon: "🧬" },
    { route: "methods", label: "Методы генетики", icon: "🔬" },
    { route: "dna", label: "ДНК-технологии", icon: "⚗" },
    { route: "diseases", label: "Болезни и синдромы", icon: "⚕" },
    { route: "flashcards", label: "Карточки повторения", icon: "▣" },
    { route: "quizzes", label: "Тесты", icon: "✓" },
    { route: "problems", label: "Генетические задачи", icon: "∑" },
    { route: "pedigree", label: "Редактор родословных", icon: "□" },
    { route: "karyotype", label: "Симулятор кариотипов", icon: "Ⅱ" },
    { route: "upload", label: "Загрузка материалов", icon: "＋" },
    { route: "editor", label: "Редактор материалов", icon: "✎" },
    { route: "ai", label: "ИИ‑агент", icon: "✦" },
    { route: "progress", label: "Прогресс", icon: "◉" }
  ];

  const defaultPedigree = () => ({
    persons: [
      { id: "p1", name: "I-1", sex: "male", status: "affected", generation: 1 },
      { id: "p2", name: "I-2", sex: "female", status: "healthy", generation: 1 },
      { id: "p3", name: "II-1", sex: "female", status: "affected", generation: 2 },
      { id: "p4", name: "II-2", sex: "male", status: "healthy", generation: 2 }
    ],
    parentChild: [
      { parentId: "p1", childId: "p3" },
      { parentId: "p2", childId: "p3" },
      { parentId: "p1", childId: "p4" },
      { parentId: "p2", childId: "p4" }
    ],
    partners: [{ a: "p1", b: "p2" }]
  });

  const initialRuntime = () => ({
    route: "home",
    selectedTopic: "all",
    selectedSectionId: window.APP_DATA.sections[0]?.id,
    selectedDiseaseCategory: "all",
    flashcardIndex: 0,
    flashcardShowAnswer: false,
    quiz: null,
    aiMessages: [{ role: "agent", text: "Привет! Я учебный ИИ‑агент. Могу объяснить тему, создать карточки/тесты, разобрать задачу или подсказать слабые места по статистике." }],
    pedigree: defaultPedigree(),
    selectedKaryotypeId: "normal-female",
    searchQuery: ""
  });

  let data = loadData();
  let runtime = initialRuntime();

  function loadData() {
    const base = deepClone(window.APP_DATA);
    try {
      const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (!stored) return base;
      for (const key of ["sections", "glossaryTerms", "diseases", "inheritanceTypes", "flashcards", "quizzes", "userMaterials", "userProgress", "editHistory", "classifications", "geneticProblems", "karyotypes"]) {
        if (stored[key]) base[key] = stored[key];
      }
      return base;
    } catch (error) {
      console.warn("Не удалось прочитать localStorage", error);
      return base;
    }
  }

  function saveData() {
    const serializable = {
      sections: data.sections,
      glossaryTerms: data.glossaryTerms,
      diseases: data.diseases,
      inheritanceTypes: data.inheritanceTypes,
      flashcards: data.flashcards,
      quizzes: data.quizzes,
      userMaterials: data.userMaterials,
      userProgress: data.userProgress,
      editHistory: data.editHistory,
      classifications: data.classifications,
      geneticProblems: data.geneticProblems,
      karyotypes: data.karyotypes
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(serializable));
  }

  function init() {
    const storedTheme = localStorage.getItem(`${STORAGE_KEY}.theme`) || "light";
    document.documentElement.dataset.theme = storedTheme;
    renderNav();
    bindChrome();
    const routeFromHash = normalizeRoute(location.hash.replace("#", ""));
    runtime.route = routeFromHash || "home";
    render();
    window.addEventListener("hashchange", () => {
      runtime.route = normalizeRoute(location.hash.replace("#", "")) || "home";
      render();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  function normalizeRoute(hash) {
    const route = hash.split("?")[0] || "home";
    return NAV.some((item) => item.route === route) || route === "search" ? route : "home";
  }

  function go(route) {
    location.hash = route;
  }

  function renderNav() {
    const nav = $("#mainNav");
    nav.innerHTML = NAV.map(item => `
      <button type="button" data-route="${item.route}">
        <span class="nav-icon">${item.icon}</span>
        <span>${item.label}</span>
      </button>
    `).join("");
    nav.addEventListener("click", (event) => {
      const btn = event.target.closest("button[data-route]");
      if (!btn) return;
      go(btn.dataset.route);
      closeSidebar();
    });
  }

  function bindChrome() {
    $("#themeToggle").addEventListener("click", toggleTheme);
    $("#exportBtn").addEventListener("click", exportData);
    $("#importInput").addEventListener("change", importData);
    $("#quickReviewBtn").addEventListener("click", () => go("flashcards"));
    $("#aiQuickBtn").addEventListener("click", () => go("ai"));
    $("#openSidebar").addEventListener("click", () => $("#sidebar").classList.add("open"));
    $("#closeSidebar").addEventListener("click", closeSidebar);
    $("#globalSearch").addEventListener("input", debounce((event) => {
      runtime.searchQuery = event.target.value.trim();
      if (runtime.searchQuery) {
        runtime.route = "search";
        if (location.hash !== "#search") history.replaceState(null, "", "#search");
      } else if (runtime.route === "search") {
        runtime.route = "home";
        history.replaceState(null, "", "#home");
      }
      render();
    }, 180));
  }

  function closeSidebar() {
    $("#sidebar").classList.remove("open");
  }

  function toggleTheme() {
    const current = document.documentElement.dataset.theme || "light";
    const next = current === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    localStorage.setItem(`${STORAGE_KEY}.theme`, next);
    toast(next === "dark" ? "Включена тёмная тема" : "Включена светлая тема");
  }

  function exportData() {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `genetics-medstudy-export-${todayISO()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  }

  function importData(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const imported = JSON.parse(String(reader.result));
        data = { ...deepClone(window.APP_DATA), ...imported };
        saveData();
        toast("Данные импортированы");
        render();
      } catch (error) {
        toast("Не удалось импортировать JSON");
      }
    };
    reader.readAsText(file);
  }

  function render() {
    data.userProgress.lastSession = new Date().toISOString();
    saveData();
    $$("#mainNav button").forEach(btn => btn.classList.toggle("active", btn.dataset.route === runtime.route));
    $("#globalSearch").value = runtime.searchQuery || "";
    const app = $("#app");
    app.innerHTML = routeTemplate();
    bindRouteEvents();
    app.focus({ preventScroll: true });
  }

  function routeTemplate() {
    switch (runtime.route) {
      case "home": return renderHome();
      case "materials": return renderMaterials();
      case "part-1": return renderTopicPage("part-1");
      case "part-2": return renderTopicPage("part-2");
      case "part-3": return renderTopicPage("part-3");
      case "glossary": return renderGlossary();
      case "classifications": return renderClassifications();
      case "inheritance": return renderInheritance();
      case "methods": return renderMethods();
      case "dna": return renderDna();
      case "diseases": return renderDiseases();
      case "flashcards": return renderFlashcards();
      case "quizzes": return renderQuizzes();
      case "problems": return renderProblems();
      case "pedigree": return renderPedigree();
      case "karyotype": return renderKaryotype();
      case "upload": return renderUpload();
      case "editor": return renderEditor();
      case "ai": return renderAI();
      case "progress": return renderProgress();
      case "search": return renderSearch();
      default: return renderHome();
    }
  }

  function bindRouteEvents() {
    $$('[data-go]').forEach(el => el.addEventListener("click", () => go(el.dataset.go)));
    $$('[data-topic]').forEach(el => el.addEventListener("click", () => {
      runtime.selectedTopic = el.dataset.topic;
      runtime.selectedSectionId = filteredSections()[0]?.id || data.sections[0]?.id;
      render();
    }));
    $$('[data-select-section]').forEach(el => el.addEventListener("click", () => {
      runtime.selectedSectionId = el.dataset.selectSection;
      markSectionRead(runtime.selectedSectionId);
      render();
    }));
    $$('[data-open-section]').forEach(el => el.addEventListener("click", () => {
      runtime.selectedSectionId = el.dataset.openSection;
      runtime.selectedTopic = "all";
      go("materials");
    }));
    $$('[data-edit-section]').forEach(el => el.addEventListener("click", () => {
      runtime.selectedSectionId = el.dataset.editSection;
      go("editor");
    }));
    $$('[data-generate-cards-section]').forEach(el => el.addEventListener("click", () => {
      generateAndSaveFlashcardsForSection(el.dataset.generateCardsSection);
    }));
    $$('[data-generate-quiz-section]').forEach(el => el.addEventListener("click", () => {
      generateAndSaveQuizForSection(el.dataset.generateQuizSection);
    }));

    const categorySelect = $("#diseaseCategory");
    if (categorySelect) categorySelect.addEventListener("change", e => { runtime.selectedDiseaseCategory = e.target.value; render(); });

    bindFlashcardEvents();
    bindQuizEvents();
    bindSimulatorEvents();
    bindUploadEvents();
    bindEditorEvents();
    bindAIEvents();
    bindPedigreeEvents();
    bindKaryotypeEvents();
  }

  function renderHome() {
    const stats = getStats();
    const due = dueFlashcards().length;
    return `
      <section class="hero">
        <div class="hero-inner">
          <p class="eyebrow">Рабочий MVP</p>
          <h1>Общая и медицинская генетика в одном локальном приложении</h1>
          <p class="lead">Навигация по трём частям методичек, поиск, глоссарий, карточки, тесты, задачи, редактор материалов, родословные, кариотипы, симулятор наследования и заготовка под ИИ‑агента.</p>
          <div class="hero-actions">
            <button class="primary" data-go="materials">Открыть материалы</button>
            <button class="secondary" data-go="flashcards">Повторить карточки (${due})</button>
            <button class="ghost" data-go="ai">Спросить ИИ‑агента</button>
          </div>
        </div>
      </section>

      <section class="grid four">
        <div class="card stat"><strong>${stats.sections}</strong><span>разделов в базе</span></div>
        <div class="card stat"><strong>${stats.flashcards}</strong><span>карточек повторения</span></div>
        <div class="card stat"><strong>${stats.quizQuestions}</strong><span>тестовых вопросов</span></div>
        <div class="card stat"><strong>${stats.progress}%</strong><span>прочитано разделов</span></div>
      </section>

      <section class="grid three" style="margin-top: 18px;">
        ${data.topics.map(topic => `
          <article class="card clickable" data-open-section="${topic.sectionIds[0]}">
            <div class="badge primary-badge">${topic.icon} ${topic.shortTitle}</div>
            <h3 style="margin-top: 12px;">${topic.title}</h3>
            <p class="muted">${topic.description}</p>
            <div class="badges">${topic.tags.map(tag => `<span class="badge">${escapeHtml(tag)}</span>`).join("")}</div>
          </article>
        `).join("")}
      </section>

      <section class="grid two" style="margin-top: 18px;">
        <article class="card">
          <h2>Что уже работает</h2>
          <p>Это не макет, а локальное SPA: данные живут в <span class="code">data.js</span>, прогресс и правки — в <span class="code">localStorage</span>. Можно читать, искать, редактировать, добавлять материалы и генерировать черновики карточек/тестов без сервера.</p>
          <div class="chips">
            <span class="chip">поиск</span><span class="chip">тёмная тема</span><span class="chip">SM‑2</span><span class="chip">родословные</span><span class="chip">кариотипы</span><span class="chip">ИИ-заготовка</span>
          </div>
        </article>
        <article class="card">
          <h2>План наполнения</h2>
          <p>Полный текст методичек добавляйте по главам в массив <span class="code">sections</span>: каждую главу лучше дробить на смысловые подразделы с <span class="code">contentHtml</span>, <span class="code">rawText</span>, тегами, источником и ссылками на болезни/термины.</p>
          <button class="secondary" data-go="upload">Добавить свой материал</button>
        </article>
      </section>
    `;
  }

  function getStats() {
    const quizQuestions = data.quizzes.reduce((sum, quiz) => sum + quiz.questions.length, 0);
    const read = new Set(data.userProgress.readSections || []).size;
    const progress = data.sections.length ? Math.round((read / data.sections.length) * 100) : 0;
    return { sections: data.sections.length, flashcards: data.flashcards.length, quizQuestions, progress };
  }

  function renderMaterials() {
    const sections = filteredSections();
    const selected = data.sections.find(s => s.id === runtime.selectedSectionId) || sections[0] || data.sections[0];
    if (selected) runtime.selectedSectionId = selected.id;
    return `
      ${pageHead("Учебные материалы", "Чтение, поиск, структура методичек", "Главный режим чтения. Тексты разделов хранятся в data.js и могут редактироваться без изменения HTML.")}
      ${topicTabs()}
      <div class="reader-layout">
        <aside class="card reader-list">
          <h3>Разделы</h3>
          ${sections.map(section => `
            <button class="list-item ${section.id === selected?.id ? "active" : ""}" data-select-section="${section.id}">
              <strong>${escapeHtml(section.title)}</strong><br>
              <span class="small">${sourceLabel(section.source)} • ${section.tags.slice(0, 3).join(", ")}</span>
            </button>
          `).join("")}
        </aside>
        <article class="card material-body">
          ${selected ? renderSectionArticle(selected) : `<div class="empty">Разделы пока не добавлены.</div>`}
        </article>
      </div>
    `;
  }

  function topicTabs() {
    const tabs = [{ id: "all", title: "Все части" }, ...data.topics.map(t => ({ id: t.id, title: t.shortTitle }))];
    return `
      <div class="tabs">
        ${tabs.map(tab => `<button class="secondary ${runtime.selectedTopic === tab.id ? "active" : ""}" data-topic="${tab.id}">${escapeHtml(tab.title)}</button>`).join("")}
      </div>
    `;
  }

  function filteredSections() {
    if (runtime.selectedTopic === "all") return data.sections.slice().sort((a, b) => a.topicId.localeCompare(b.topicId) || a.order - b.order);
    return data.sections.filter(s => s.topicId === runtime.selectedTopic).sort((a, b) => a.order - b.order);
  }

  function renderSectionArticle(section) {
    const read = (data.userProgress.readSections || []).includes(section.id);
    return `
      <div class="section-meta">
        <div class="badges">
          <span class="badge primary-badge">${sourceLabel(section.source)}</span>
          <span class="badge">${section.type}</span>
          ${read ? `<span class="badge">прочитано</span>` : ""}
        </div>
        <div class="actions" style="margin:0;">
          <button class="secondary" data-edit-section="${section.id}">Редактировать</button>
          <button class="ghost" data-generate-cards-section="${section.id}">Карточки</button>
          <button class="ghost" data-generate-quiz-section="${section.id}">Тест</button>
        </div>
      </div>
      <h2>${escapeHtml(section.title)}</h2>
      <p class="lead">${escapeHtml(section.summary || "")}</p>
      <div class="badges">${(section.tags || []).map(tag => `<span class="badge">${escapeHtml(tag)}</span>`).join("")}</div>
      <hr>
      ${section.contentHtml}
    `;
  }

  function renderTopicPage(topicId) {
    const topic = data.topics.find(t => t.id === topicId);
    const sections = data.sections.filter(s => s.topicId === topicId).sort((a, b) => a.order - b.order);
    return `
      ${pageHead(topic.title, "Логика методички", topic.description)}
      <section class="grid three">
        ${sections.map(section => `
          <article class="card clickable" data-open-section="${section.id}">
            <div class="badges"><span class="badge primary-badge">${sourceLabel(section.source)}</span><span class="badge">${section.type}</span></div>
            <h3 style="margin-top: 12px;">${escapeHtml(section.title)}</h3>
            <p class="muted">${escapeHtml(section.summary || "")}</p>
            <div class="badges">${section.tags.slice(0, 4).map(tag => `<span class="badge">${escapeHtml(tag)}</span>`).join("")}</div>
          </article>
        `).join("")}
      </section>
    `;
  }

  function renderGlossary() {
    const groups = groupBy(data.glossaryTerms.sort((a, b) => a.term.localeCompare(b.term, "ru")), term => term.term[0].toUpperCase());
    return `
      ${pageHead("Глоссарий терминов", "Быстрый справочник", "Термины связаны с разделами, карточками и тестами. Добавляйте новые определения в glossaryTerms.")}
      <section class="grid two">
        ${Object.entries(groups).map(([letter, terms]) => `
          <article class="card">
            <h2>${letter}</h2>
            ${terms.map(term => `
              <div class="compact card" style="margin-bottom:10px;">
                <h3>${escapeHtml(term.term)}</h3>
                <p>${escapeHtml(term.definition)}</p>
                <p class="small">${escapeHtml(term.full || "")}</p>
                <div class="actions"><button class="ghost" data-open-section="${term.sectionId}">Открыть источник</button></div>
              </div>
            `).join("")}
          </article>
        `).join("")}
      </section>
    `;
  }

  function renderClassifications() {
    return `
      ${pageHead("Классификации", "Систематизация материала", "Классификации помогают быстро повторять крупные блоки: мутации, методы, признаки наследственной патологии, ДНК‑технологии.")}
      <section class="grid three">
        ${data.classifications.map(item => `
          <article class="card">
            <span class="badge primary-badge">${escapeHtml(item.group)}</span>
            <h3 style="margin-top:12px;">${escapeHtml(item.title)}</h3>
            <ul>${item.items.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>
            <button class="secondary" data-open-section="${item.sectionId}">Открыть раздел</button>
          </article>
        `).join("")}
      </section>
    `;
  }

  function renderInheritance() {
    return `
      ${pageHead("Типы наследования и симулятор", "Родословные + вероятности", "Выберите тип наследования и генотипы родителей: приложение построит решётку Пеннета, вероятности генотипов/фенотипов и объяснение.")}
      <section class="grid two">
        <article class="card">
          <h2>Справочник типов наследования</h2>
          <div class="grid">
            ${data.inheritanceTypes.map(type => `
              <div class="card compact">
                <h3>${escapeHtml(type.name)} <span class="badge">${escapeHtml(type.short)}</span></h3>
                <p><strong>Типичный риск:</strong> ${escapeHtml(type.typicalRisk)}</p>
                <ul>${type.keyFeatures.map(f => `<li>${escapeHtml(f)}</li>`).join("")}</ul>
                <p class="small">Примеры: ${type.examples.map(escapeHtml).join(", ")}</p>
              </div>
            `).join("")}
          </div>
        </article>
        <article class="card" id="simulatorCard">
          ${renderInheritanceSimulator()}
        </article>
      </section>
    `;
  }

  function renderInheritanceSimulator() {
    const selectedType = runtime.simType || "AD";
    const type = data.inheritanceTypes.find(t => t.id === selectedType) || data.inheritanceTypes[0];
    const p1Options = type.genotypes?.parent1 || ["Aa", "AA", "aa"];
    const p2Options = type.genotypes?.parent2 || ["Aa", "AA", "aa"];
    runtime.simP1 ||= p1Options[0];
    runtime.simP2 ||= p2Options[0];
    if (!p1Options.includes(runtime.simP1)) runtime.simP1 = p1Options[0];
    if (!p2Options.includes(runtime.simP2)) runtime.simP2 = p2Options[0];
    const result = simulateInheritance(type.id, runtime.simP1, runtime.simP2);
    return `
      <h2>Симулятор наследования</h2>
      <div class="form-grid">
        <div class="form-row">
          <label>Тип наследования</label>
          <select id="simType">${data.inheritanceTypes.map(t => `<option value="${t.id}" ${t.id === type.id ? "selected" : ""}>${escapeHtml(t.name)}</option>`).join("")}</select>
        </div>
        <div class="grid two">
          <div class="form-row"><label>Генотип родителя 1 / матери</label><select id="simP1">${p1Options.map(g => `<option ${g === runtime.simP1 ? "selected" : ""}>${escapeHtml(g)}</option>`).join("")}</select></div>
          <div class="form-row"><label>Генотип родителя 2 / отца</label><select id="simP2">${p2Options.map(g => `<option ${g === runtime.simP2 ? "selected" : ""}>${escapeHtml(g)}</option>`).join("")}</select></div>
        </div>
      </div>
      <hr>
      <h3>Решётка Пеннета</h3>
      ${renderPunnett(result)}
      <h3>Вероятности</h3>
      <table class="data-table"><thead><tr><th>Генотип</th><th>Вероятность</th><th>Фенотип/интерпретация</th></tr></thead><tbody>
        ${Object.entries(result.counts).map(([g, count]) => `<tr><td>${escapeHtml(g)}</td><td>${Math.round(count / result.total * 100)}%</td><td>${escapeHtml(result.phenotype(g, type.id))}</td></tr>`).join("")}
      </tbody></table>
      <div class="feedback">${escapeHtml(result.explanation)}</div>
    `;
  }

  function bindSimulatorEvents() {
    const type = $("#simType");
    if (!type) return;
    type.addEventListener("change", (e) => { runtime.simType = e.target.value; runtime.simP1 = null; runtime.simP2 = null; render(); });
    $("#simP1")?.addEventListener("change", (e) => { runtime.simP1 = e.target.value; render(); });
    $("#simP2")?.addEventListener("change", (e) => { runtime.simP2 = e.target.value; render(); });
  }

  function simulateInheritance(typeId, p1, p2) {
    const gametes1 = gametesFromGenotype(p1);
    const gametes2 = gametesFromGenotype(p2);
    const cells = [];
    const counts = {};
    for (const g1 of gametes1) {
      const row = [];
      for (const g2 of gametes2) {
        const child = normalizeChildGenotype(g1, g2, typeId);
        counts[child] = (counts[child] || 0) + 1;
        row.push({ g1, g2, child });
      }
      cells.push(row);
    }
    const phenotype = (genotype, type) => phenotypeFromGenotype(genotype, type);
    const explanation = inheritanceExplanation(typeId, p1, p2, counts, gametes1.length * gametes2.length);
    return { gametes1, gametes2, cells, counts, total: gametes1.length * gametes2.length, phenotype, explanation };
  }

  function gametesFromGenotype(genotype) {
    if (genotype.includes("X") || genotype.includes("Y")) {
      const tokens = genotype.match(/X[AaHh]?|Y\*?|mt\+|mt\*|\w+/g) || [genotype];
      if (tokens.length <= 1) return tokens;
      return unique(tokens);
    }
    if (genotype.startsWith("mt")) return [genotype];
    const chars = genotype.replace(/[^A-Za-zА-Яа-я]/g, "").split("");
    return unique(chars.length ? chars : [genotype]);
  }

  function normalizeChildGenotype(g1, g2, typeId) {
    if (typeId === "MT") return g1.includes("*") ? "mt*" : "mt+";
    if (typeId === "Y") return `${g1}${g2}`.includes("Y*") ? "XY*" : `${g1}${g2}`.includes("Y") ? "XY" : "XX";
    if (g1.startsWith("X") || g2.startsWith("X") || g1.startsWith("Y") || g2.startsWith("Y")) {
      return [g1, g2].sort((a, b) => (a.startsWith("X") && b.startsWith("Y") ? -1 : a.localeCompare(b))).join("");
    }
    const pair = [g1, g2].sort((a, b) => (isDominantAllele(a) === isDominantAllele(b) ? a.localeCompare(b) : isDominantAllele(a) ? -1 : 1));
    return pair.join("");
  }

  function isDominantAllele(a) {
    return a === a.toUpperCase() && a !== a.toLowerCase();
  }

  function phenotypeFromGenotype(genotype, typeId) {
    if (typeId === "AD") return genotype.includes("A") ? "признак проявляется" : "здоров по признаку";
    if (typeId === "AR") return genotype.toLowerCase() === genotype ? "больной" : genotype.includes("a") ? "носитель" : "здоров без мутантного аллеля";
    if (typeId === "XR") return genotype.includes("XaY") || genotype.includes("XaXa") ? "больной" : genotype.includes("Xa") ? "носительница" : "здоров";
    if (typeId === "XD") return genotype.includes("XA") ? "признак проявляется" : "здоров";
    if (typeId === "Y") return genotype.includes("Y*") ? "Y-сцепленный признак у мужчины" : "признак отсутствует";
    if (typeId === "MT") return genotype === "mt*" ? "риск митохондриального заболевания зависит от гетероплазмии" : "митохондриальная мутация не передана";
    return "интерпретация не задана";
  }

  function inheritanceExplanation(typeId, p1, p2, counts, total) {
    const type = data.inheritanceTypes.find(t => t.id === typeId);
    const variants = Object.entries(counts).map(([g, c]) => `${g}: ${Math.round(c / total * 100)}%`).join("; ");
    return `${type?.short || typeId}: ${p1} × ${p2}. Возможные варианты потомства: ${variants}. ${type?.typicalRisk || ""}`;
  }

  function renderPunnett(result) {
    return `
      <table class="data-table punnett-table">
        <thead><tr><th class="corner"></th>${result.gametes2.map(g => `<th>${escapeHtml(g)}</th>`).join("")}</tr></thead>
        <tbody>
          ${result.cells.map((row, idx) => `<tr><th>${escapeHtml(result.gametes1[idx])}</th>${row.map(cell => `<td>${escapeHtml(cell.child)}</td>`).join("")}</tr>`).join("")}
        </tbody>
      </table>
    `;
  }

  function renderMethods() {
    const methodSections = data.sections.filter(s => s.type === "method");
    return `
      ${pageHead("Методы генетики человека", "От родословной до ДНК-диагностики", "Разделы методички о клинико‑генеалогическом, цитогенетическом, биохимическом и молекулярно‑генетическом методах.")}
      <section class="grid two">
        ${methodSections.map(section => `
          <article class="card clickable" data-open-section="${section.id}">
            <span class="badge primary-badge">${sourceLabel(section.source)}</span>
            <h3 style="margin-top: 12px;">${escapeHtml(section.title)}</h3>
            <p class="muted">${escapeHtml(section.summary)}</p>
            <div class="badges">${section.tags.map(t => `<span class="badge">${escapeHtml(t)}</span>`).join("")}</div>
          </article>
        `).join("")}
      </section>
    `;
  }

  function renderDna() {
    const section = data.sections.find(s => s.id === "dna-technologies");
    const molecular = data.sections.find(s => s.id === "molecular-diagnostics");
    const tech = data.classifications.find(c => c.id === "dna-tech-list");
    return `
      ${pageHead("ДНК‑технологии", "Справочник методов", "Выделение ДНК, рестриктазы, электрофорез, ПЦР, гибридизация, Саузерн‑блоттинг, секвенирование, генная инженерия, генотерапия и RNA‑интерференция.")}
      <section class="grid two">
        <article class="card material-body">${renderSectionArticle(molecular)}</article>
        <article class="card material-body">${renderSectionArticle(section)}</article>
      </section>
      <section class="card" style="margin-top:18px;">
        <h2>Подразделы для наполнения</h2>
        <div class="grid three">${tech.items.map(item => `<div class="card compact"><strong>${escapeHtml(item)}</strong><p class="small">Добавьте сюда полный фрагмент методички, таблицы, схемы и проверочные вопросы.</p></div>`).join("")}</div>
      </section>
    `;
  }

  function renderDiseases() {
    const categories = ["all", ...unique(data.diseases.map(d => d.category))];
    const diseases = runtime.selectedDiseaseCategory === "all" ? data.diseases : data.diseases.filter(d => d.category === runtime.selectedDiseaseCategory);
    return `
      ${pageHead("Наследственные болезни и синдромы", "Справочник патологий", "Карточки заболеваний рассчитаны на медицинский уровень: наследование, ген/локус, симптомы, диагностика, подходы к лечению и связь с разделом.")}
      <div class="tabs">
        ${categories.map(cat => `<button class="secondary ${runtime.selectedDiseaseCategory === cat ? "active" : ""}" onclick="void(0)" data-disease-tab="${escapeAttr(cat)}">${cat === "all" ? "Все" : escapeHtml(cat)}</button>`).join("")}
      </div>
      <section class="grid two">
        ${diseases.map(d => diseaseCard(d)).join("")}
      </section>
    `;
  }

  function diseaseCard(d) {
    const inheritance = data.inheritanceTypes.find(t => t.id === d.inheritance)?.short || d.inheritance;
    return `
      <article class="card">
        <div class="badges"><span class="badge primary-badge">${escapeHtml(d.category)}</span><span class="badge">${escapeHtml(inheritance)}</span></div>
        <h3 style="margin-top: 12px;">${escapeHtml(d.name)}</h3>
        <p><strong>Ген/локус:</strong> ${escapeHtml(d.gene)}</p>
        <p><strong>Манифестация:</strong> ${escapeHtml(d.onset)}</p>
        <p><strong>Основные симптомы:</strong> ${d.symptoms.map(escapeHtml).join(", ")}</p>
        <p><strong>Диагностика:</strong> ${d.diagnostics.map(escapeHtml).join(", ")}</p>
        <p><strong>Лечение/подходы:</strong> ${escapeHtml(d.treatment)}</p>
        <div class="actions"><button class="secondary" data-open-section="${d.sectionId}">Связанный раздел</button></div>
        <div class="badges">${d.tags.map(tag => `<span class="badge">${escapeHtml(tag)}</span>`).join("")}</div>
      </article>
    `;
  }

  function bindFlashcardEvents() {
    const show = $("#showAnswerBtn");
    if (!show) return;
    show.addEventListener("click", () => { runtime.flashcardShowAnswer = true; render(); });
    $("#cardKnowBtn")?.addEventListener("click", () => gradeCurrentCard(true));
    $("#cardRepeatBtn")?.addEventListener("click", () => gradeCurrentCard(false));
    $("#nextCardBtn")?.addEventListener("click", () => { runtime.flashcardIndex = (runtime.flashcardIndex + 1) % Math.max(1, currentFlashcardDeck().length); runtime.flashcardShowAnswer = false; render(); });
    $("#flashcardFilter")?.addEventListener("change", e => { runtime.cardFilter = e.target.value; runtime.flashcardIndex = 0; runtime.flashcardShowAnswer = false; render(); });
  }

  function renderFlashcards() {
    const deck = currentFlashcardDeck();
    const card = deck[runtime.flashcardIndex % Math.max(deck.length, 1)];
    const tags = ["all", "due", ...unique(data.flashcards.flatMap(c => c.tags || []))];
    return `
      ${pageHead("Карточки повторения", "Интервальное повторение", "Карточки поддерживают вопрос, краткий ответ, объяснение, источник, сложность, теги и SM‑2‑подобное планирование через localStorage.")}
      <section class="card">
        <div class="section-meta">
          <div class="form-row" style="min-width:240px;"><label>Фильтр</label><select id="flashcardFilter">${tags.map(tag => `<option value="${escapeAttr(tag)}" ${runtime.cardFilter === tag ? "selected" : ""}>${tag === "all" ? "Все" : tag === "due" ? "К повторению сегодня" : escapeHtml(tag)}</option>`).join("")}</select></div>
          <div class="badges"><span class="badge">в колоде: ${deck.length}</span><span class="badge">сегодня: ${dueFlashcards().length}</span></div>
        </div>
        ${card ? renderFlashcard(card) : `<div class="empty">Нет карточек по выбранному фильтру.</div>`}
      </section>
    `;
  }

  function renderFlashcard(card) {
    const progress = data.userProgress.flashcards?.[card.id] || card;
    return `
      <div class="flashcard-stage">
        <div class="flashcard">
          <div>
            <div class="badges">
              <span class="badge primary-badge">сложность ${card.difficulty}/3</span>
              <span class="badge">${escapeHtml(card.source)}</span>
              <span class="badge">след.: ${progress.due ? escapeHtml(progress.due) : "сегодня"}</span>
            </div>
            <p class="question">${escapeHtml(card.question)}</p>
          </div>
          <div>
            ${runtime.flashcardShowAnswer ? `
              <div class="answer">
                <h3>Краткий ответ</h3>
                <p>${escapeHtml(card.shortAnswer)}</p>
                <h3>Пояснение</h3>
                <p class="explanation">${escapeHtml(card.explanation)}</p>
              </div>
              <div class="actions">
                <button class="success" id="cardKnowBtn">Знаю</button>
                <button class="danger" id="cardRepeatBtn">Повторить</button>
                <button class="secondary" id="nextCardBtn">Следующая</button>
              </div>
            ` : `
              <button class="primary" id="showAnswerBtn">Показать ответ</button>
            `}
          </div>
        </div>
      </div>
    `;
  }

  function currentFlashcardDeck() {
    const filter = runtime.cardFilter || "due";
    if (filter === "due") return dueFlashcards();
    if (filter === "all") return data.flashcards;
    return data.flashcards.filter(card => (card.tags || []).includes(filter));
  }

  function dueFlashcards() {
    const today = todayISO();
    return data.flashcards.filter(card => {
      const progress = data.userProgress.flashcards?.[card.id];
      return !progress?.due || progress.due <= today;
    });
  }

  function gradeCurrentCard(known) {
    const deck = currentFlashcardDeck();
    const card = deck[runtime.flashcardIndex % Math.max(deck.length, 1)];
    if (!card) return;
    const current = data.userProgress.flashcards?.[card.id] || { interval: 0, repetition: 0, ease: 2.5, due: todayISO() };
    const next = sm2(current, known ? 5 : 2);
    data.userProgress.flashcards ||= {};
    data.userProgress.flashcards[card.id] = next;
    saveData();
    runtime.flashcardShowAnswer = false;
    runtime.flashcardIndex = 0;
    toast(known ? `Отлично. Следующее повторение: ${next.due}` : "Карточка вернётся завтра");
    render();
  }

  function sm2(cardProgress, quality) {
    let { repetition = 0, interval = 0, ease = 2.5 } = cardProgress;
    if (quality < 3) {
      repetition = 0;
      interval = 1;
    } else {
      repetition += 1;
      if (repetition === 1) interval = 1;
      else if (repetition === 2) interval = 6;
      else interval = Math.round(interval * ease);
      ease = Math.max(1.3, ease + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)));
    }
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + interval);
    return { repetition, interval, ease, due: dueDate.toISOString().slice(0, 10), lastGrade: quality, updatedAt: new Date().toISOString() };
  }

  function renderQuizzes() {
    if (runtime.quiz) return renderQuizRunner();
    return `
      ${pageHead("Тесты", "Проверка знаний", "Поддерживаются одиночный выбор, множественный выбор, верно/неверно, открытый вопрос, сопоставление и генетическая задача с решением.")}
      <section class="grid two">
        ${data.quizzes.map(quiz => `
          <article class="card">
            <h3>${escapeHtml(quiz.title)}</h3>
            <p>${escapeHtml(quiz.description)}</p>
            <div class="badges"><span class="badge">${quiz.questions.length} вопросов</span>${quiz.tags.map(t => `<span class="badge">${escapeHtml(t)}</span>`).join("")}</div>
            <div class="actions"><button class="primary" data-start-quiz="${quiz.id}">Начать тест</button></div>
          </article>
        `).join("")}
      </section>
    `;
  }

  function bindQuizEvents() {
    $$('[data-start-quiz]').forEach(btn => btn.addEventListener("click", () => startQuiz(btn.dataset.startQuiz)));
    $("#checkQuizAnswer")?.addEventListener("click", checkQuizAnswer);
    $("#nextQuizQuestion")?.addEventListener("click", nextQuizQuestion);
    $("#finishQuiz")?.addEventListener("click", finishQuiz);
    $("#resetQuiz")?.addEventListener("click", () => { runtime.quiz = null; render(); });
  }

  function startQuiz(quizId) {
    runtime.quiz = { quizId, index: 0, answers: {}, checked: {}, score: 0, finished: false };
    render();
  }

  function renderQuizRunner() {
    const quiz = data.quizzes.find(q => q.id === runtime.quiz.quizId);
    const q = quiz.questions[runtime.quiz.index];
    if (runtime.quiz.finished) return renderQuizResult(quiz);
    return `
      ${pageHead(quiz.title, `Вопрос ${runtime.quiz.index + 1} из ${quiz.questions.length}`, quiz.description)}
      <section class="card">
        <div class="progress-bar"><span style="width:${(runtime.quiz.index / quiz.questions.length) * 100}%"></span></div>
        <h2 style="margin-top:18px;">${escapeHtml(q.question)}</h2>
        <div id="quizQuestionArea">${renderQuestionInput(q)}</div>
        ${runtime.quiz.checked[q.id] ? `<div class="feedback"><strong>${runtime.quiz.checked[q.id].correct ? "Верно" : "Не совсем"}.</strong> ${escapeHtml(q.explanation || q.solution?.join(" ") || "")}</div>` : ""}
        <div class="actions">
          ${runtime.quiz.checked[q.id] ? `<button class="primary" id="nextQuizQuestion">${runtime.quiz.index === quiz.questions.length - 1 ? "Завершить" : "Следующий вопрос"}</button>` : `<button class="primary" id="checkQuizAnswer">Проверить</button>`}
          <button class="ghost" id="resetQuiz">Выйти</button>
        </div>
      </section>
    `;
  }

  function renderQuestionInput(q) {
    if (q.type === "single") return q.options.map((o, i) => `<label class="quiz-option"><input type="radio" name="quizAnswer" value="${escapeAttr(o)}"> ${escapeHtml(o)}</label>`).join("");
    if (q.type === "multiple") return q.options.map(o => `<label class="quiz-option"><input type="checkbox" name="quizAnswer" value="${escapeAttr(o)}"> ${escapeHtml(o)}</label>`).join("");
    if (q.type === "truefalse") return `<label class="quiz-option"><input type="radio" name="quizAnswer" value="true"> Верно</label><label class="quiz-option"><input type="radio" name="quizAnswer" value="false"> Неверно</label>`;
    if (q.type === "open" || q.type === "genetic_problem") return `<textarea id="openAnswer" placeholder="Введите ответ. Для задач можно писать ход решения."></textarea>${q.solution ? `<details><summary>Подсказка: структура решения</summary><ol>${q.solution.map(s => `<li>${escapeHtml(s)}</li>`).join("")}</ol></details>` : ""}`;
    if (q.type === "matching") {
      const shuffledRight = shuffle(q.pairs.map(p => p.right));
      return q.pairs.map((pair, idx) => `
        <div class="matching-row">
          <strong style="min-width: 190px;">${escapeHtml(pair.left)}</strong>
          <select data-match-index="${idx}">
            <option value="">Выберите...</option>
            ${shuffledRight.map(r => `<option value="${escapeAttr(r)}">${escapeHtml(r)}</option>`).join("")}
          </select>
        </div>
      `).join("");
    }
    return `<textarea id="openAnswer"></textarea>`;
  }

  function checkQuizAnswer() {
    const quiz = data.quizzes.find(q => q.id === runtime.quiz.quizId);
    const q = quiz.questions[runtime.quiz.index];
    const answer = collectAnswer(q);
    const correct = isAnswerCorrect(q, answer);
    runtime.quiz.answers[q.id] = answer;
    runtime.quiz.checked[q.id] = { correct, checkedAt: new Date().toISOString() };
    if (correct) runtime.quiz.score += 1;
    saveQuizProgress(quiz.id, q.id, correct, q.tags || quiz.tags || []);
    render();
  }

  function collectAnswer(q) {
    if (["single", "truefalse"].includes(q.type)) {
      const checked = $('input[name="quizAnswer"]:checked');
      if (!checked) return null;
      return q.type === "truefalse" ? checked.value === "true" : checked.value;
    }
    if (q.type === "multiple") return $$('input[name="quizAnswer"]:checked').map(input => input.value);
    if (q.type === "open" || q.type === "genetic_problem") return $("#openAnswer")?.value.trim() || "";
    if (q.type === "matching") return $$('[data-match-index]').map(select => ({ index: Number(select.dataset.matchIndex), value: select.value }));
    return null;
  }

  function isAnswerCorrect(q, answer) {
    if (q.type === "single") return answer === q.answer;
    if (q.type === "truefalse") return answer === q.answer;
    if (q.type === "multiple") return arraysEqual((answer || []).sort(), q.answer.slice().sort());
    if (q.type === "open") {
      const lower = normalizeText(answer);
      const hits = (q.keywords || []).filter(k => lower.includes(normalizeText(k))).length;
      return hits >= Math.max(1, Math.ceil((q.keywords || []).length * 0.5));
    }
    if (q.type === "genetic_problem") return normalizeText(answer).includes("25") || normalizeText(answer).includes("aa") || normalizeText(answer).includes("аa");
    if (q.type === "matching") return answer.every(a => q.pairs[a.index]?.right === a.value);
    return false;
  }

  function nextQuizQuestion() {
    const quiz = data.quizzes.find(q => q.id === runtime.quiz.quizId);
    if (runtime.quiz.index >= quiz.questions.length - 1) {
      runtime.quiz.finished = true;
    } else {
      runtime.quiz.index += 1;
    }
    render();
  }

  function finishQuiz() {
    runtime.quiz.finished = true;
    render();
  }

  function renderQuizResult(quiz) {
    const percent = Math.round((runtime.quiz.score / quiz.questions.length) * 100);
    const weak = data.userProgress.weakTags || [];
    return `
      ${pageHead("Результат теста", `${runtime.quiz.score}/${quiz.questions.length} — ${percent}%`, percent >= 80 ? "Отличный результат. Закрепи материал карточками." : "Есть слабые места: приложение добавит их в рекомендации.")}
      <section class="card">
        <div class="progress-bar"><span style="width:${percent}%"></span></div>
        <h2 style="margin-top:18px;">${percent}%</h2>
        <p>${percent >= 80 ? "Тема усвоена хорошо." : "Рекомендуется повторить теорию и пройти карточки по слабым тегам."}</p>
        <p><strong>Слабые теги:</strong> ${weak.length ? weak.map(escapeHtml).join(", ") : "пока не выявлены"}</p>
        <div class="actions"><button class="primary" id="resetQuiz">К списку тестов</button><button class="secondary" data-go="flashcards">Повторить карточки</button></div>
      </section>
    `;
  }

  function saveQuizProgress(quizId, questionId, correct, tags) {
    data.userProgress.quizzes ||= {};
    data.userProgress.quizzes[quizId] ||= { attempts: 0, correct: 0, questions: {} };
    const record = data.userProgress.quizzes[quizId];
    record.attempts += 1;
    if (correct) record.correct += 1;
    record.questions[questionId] = { correct, answeredAt: new Date().toISOString() };
    if (!correct) {
      data.userProgress.weakTags = unique([...(data.userProgress.weakTags || []), ...tags]);
    }
    saveData();
  }

  function renderProblems() {
    return `
      ${pageHead("Генетические задачи", "Условия, решение, объяснение", "Блок для задач в формате российских вузов: дано, решение, ответ, пояснение. Можно генерировать новые задачи через ИИ‑агента.")}
      <section class="grid two">
        ${data.geneticProblems.map(problem => `
          <article class="card">
            <h3>${escapeHtml(problem.title)}</h3>
            <p>${escapeHtml(problem.condition)}</p>
            <h4>Дано</h4>
            <ul>${problem.givens.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>
            <details><summary>Показать решение</summary><p><strong>Ответ:</strong> ${escapeHtml(problem.answer)}</p><p>${escapeHtml(problem.explanation)}</p></details>
          </article>
        `).join("")}
      </section>
    `;
  }

  function renderUpload() {
    return `
      ${pageHead("Загрузка пользовательских материалов", "Конспекты, фрагменты методичек, свои заметки", "Локальная версия читает TXT/MD/HTML. PDF/DOCX лучше предварительно конвертировать или подключить backend-парсер на следующем этапе.")}
      <section class="grid two">
        <article class="card">
          <h2>Добавить материал</h2>
          <div class="form-grid">
            <div class="form-row"><label>Название</label><input id="materialTitle" placeholder="Например: Конспект по эпистазу"></div>
            <div class="form-row"><label>Теги через запятую</label><input id="materialTags" placeholder="эпистаз, неаллельные гены"></div>
            <div class="form-row"><label>Файл TXT/MD/HTML</label><input id="materialFile" type="file" accept=".txt,.md,.html,text/plain,text/markdown,text/html"></div>
            <div class="form-row"><label>Или вставьте текст вручную</label><textarea id="materialText" placeholder="Вставьте сюда фрагмент методички или свой конспект"></textarea></div>
            <button class="primary" id="saveMaterialBtn">Сохранить материал</button>
          </div>
        </article>
        <article class="card">
          <h2>Ваши материалы</h2>
          ${data.userMaterials.length ? data.userMaterials.map(m => `
            <div class="card compact" style="margin-bottom:10px;">
              <h3>${escapeHtml(m.title)}</h3>
              <p class="small">${m.tags.map(escapeHtml).join(", ")} • ${new Date(m.createdAt).toLocaleString("ru-RU")}</p>
              <div class="actions"><button class="secondary" data-generate-user-cards="${m.id}">Карточки</button><button class="ghost" data-delete-material="${m.id}">Удалить</button></div>
            </div>
          `).join("") : `<div class="empty">Пока нет пользовательских материалов.</div>`}
        </article>
      </section>
    `;
  }

  function bindUploadEvents() {
    $("#materialFile")?.addEventListener("change", async (event) => {
      const file = event.target.files?.[0];
      if (!file) return;
      const text = await file.text();
      $("#materialText").value = text;
      if (!$("#materialTitle").value) $("#materialTitle").value = file.name.replace(/\.[^.]+$/, "");
    });
    $("#saveMaterialBtn")?.addEventListener("click", () => {
      const title = $("#materialTitle").value.trim();
      const text = $("#materialText").value.trim();
      const tags = $("#materialTags").value.split(",").map(x => x.trim()).filter(Boolean);
      if (!title || !text) return toast("Добавьте название и текст материала");
      const material = { id: uid("um"), title, text, tags, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      data.userMaterials.push(material);
      data.editHistory.push({ id: uid("hist"), entity: "userMaterials", entityId: material.id, action: "create", at: new Date().toISOString(), title });
      saveData();
      toast("Материал сохранён");
      render();
    });
    $$('[data-delete-material]').forEach(btn => btn.addEventListener("click", () => {
      data.userMaterials = data.userMaterials.filter(m => m.id !== btn.dataset.deleteMaterial);
      data.editHistory.push({ id: uid("hist"), entity: "userMaterials", entityId: btn.dataset.deleteMaterial, action: "delete", at: new Date().toISOString() });
      saveData();
      render();
    }));
    $$('[data-generate-user-cards]').forEach(btn => btn.addEventListener("click", () => {
      const material = data.userMaterials.find(m => m.id === btn.dataset.generateUserCards);
      if (!material) return;
      const cards = generateFlashcardsFromText(material.text, { source: material.title, sectionId: "user" });
      data.flashcards.push(...cards);
      saveData();
      toast(`Создано карточек: ${cards.length}`);
      go("flashcards");
    }));
  }

  function renderEditor() {
    const selected = data.sections.find(s => s.id === runtime.selectedSectionId) || data.sections[0];
    return `
      ${pageHead("Редактор материалов", "Правки с историей", "Можно исправлять существующие разделы, добавлять HTML-разметку и rawText для поиска/генерации. Все версии фиксируются в editHistory.")}
      <div class="reader-layout">
        <aside class="card reader-list">
          <h3>Разделы курса</h3>
          ${data.sections.map(section => `<button class="list-item ${section.id === selected.id ? "active" : ""}" data-select-section="${section.id}">${escapeHtml(section.title)}<br><span class="small">${sourceLabel(section.source)}</span></button>`).join("")}
        </aside>
        <article class="card">
          <h2>Редактировать раздел</h2>
          <div class="form-grid">
            <div class="form-row"><label>Название</label><input id="editTitle" value="${escapeAttr(selected.title)}"></div>
            <div class="form-row"><label>Краткое резюме</label><textarea id="editSummary">${escapeHtml(selected.summary || "")}</textarea></div>
            <div class="form-row"><label>Теги через запятую</label><input id="editTags" value="${escapeAttr((selected.tags || []).join(", "))}"></div>
            <div class="form-row"><label>HTML-содержимое</label><textarea id="editContent" style="min-height:260px;">${escapeHtml(selected.contentHtml || "")}</textarea></div>
            <div class="form-row"><label>RawText для поиска и ИИ</label><textarea id="editRaw">${escapeHtml(selected.rawText || "")}</textarea></div>
            <div class="actions"><button class="primary" id="saveSectionEdit">Сохранить правку</button><button class="secondary" data-open-section="${selected.id}">Открыть в чтении</button></div>
          </div>
        </article>
      </div>
    `;
  }

  function bindEditorEvents() {
    $("#saveSectionEdit")?.addEventListener("click", () => {
      const section = data.sections.find(s => s.id === runtime.selectedSectionId);
      if (!section) return;
      const before = deepClone(section);
      section.title = $("#editTitle").value.trim();
      section.summary = $("#editSummary").value.trim();
      section.tags = $("#editTags").value.split(",").map(x => x.trim()).filter(Boolean);
      section.contentHtml = $("#editContent").value;
      section.rawText = $("#editRaw").value.trim();
      section.updatedAt = new Date().toISOString();
      data.editHistory.push({ id: uid("hist"), entity: "sections", entityId: section.id, action: "update", at: new Date().toISOString(), before, after: deepClone(section), title: section.title });
      saveData();
      toast("Раздел сохранён");
      render();
    });
  }

  function renderAI() {
    return `
      ${pageHead("Чат / панель ИИ‑агента", "Архитектура под настоящий API", "Сейчас работает локальный симулятор. Функции generateFlashcardsFromText(text) и generateQuizFromText(text) уже есть; реальный API подключается через callRealAI().")}
      <section class="grid two">
        <article class="card ai-chat">
          <div class="messages" id="aiMessages">
            ${runtime.aiMessages.map(m => `<div class="message ${m.role === "user" ? "user" : "agent"}">${formatMessage(m.text)}</div>`).join("")}
          </div>
          <div class="ai-input">
            <textarea id="aiInput" placeholder="Например: объясни разницу между пенетрантностью и экспрессивностью"></textarea>
            <button class="primary" id="sendAI">Отправить</button>
          </div>
        </article>
        <article class="card">
          <h2>Генератор карточек и тестов</h2>
          <div class="form-grid">
            <div class="form-row"><label>Выберите раздел</label><select id="aiSectionSelect">${data.sections.map(s => `<option value="${s.id}">${escapeHtml(s.title)}</option>`).join("")}</select></div>
            <button class="secondary" id="aiGenerateCards">Сгенерировать карточки по разделу</button>
            <button class="secondary" id="aiGenerateQuiz">Сгенерировать тест по разделу</button>
          </div>
          <hr>
          <h3>Промпт для карточек</h3>
          <pre>${escapeHtml(data.aiPrompts.flashcards)}</pre>
          <h3>JSON-формат ответа</h3>
          <pre>${escapeHtml(JSON.stringify({ flashcards: [{ question: "Что такое ...?", shortAnswer: "...", explanation: "...", source: "Ч.2, раздел ...", difficulty: 2, tags: ["..."] }] }, null, 2))}</pre>
        </article>
      </section>
    `;
  }

  function bindAIEvents() {
    $("#sendAI")?.addEventListener("click", sendAIMessage);
    $("#aiInput")?.addEventListener("keydown", e => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) sendAIMessage();
    });
    $("#aiGenerateCards")?.addEventListener("click", () => generateAndSaveFlashcardsForSection($("#aiSectionSelect").value));
    $("#aiGenerateQuiz")?.addEventListener("click", () => generateAndSaveQuizForSection($("#aiSectionSelect").value));
  }

  function sendAIMessage() {
    const input = $("#aiInput");
    const text = input.value.trim();
    if (!text) return;
    runtime.aiMessages.push({ role: "user", text });
    runtime.aiMessages.push({ role: "agent", text: mockAIAgent(text) });
    input.value = "";
    render();
    const messages = $("#aiMessages");
    messages?.scrollTo({ top: messages.scrollHeight });
  }

  function mockAIAgent(text) {
    const q = normalizeText(text);
    if (q.includes("пенетрант")) return "Пенетрантность — это вероятность проявления мутантного аллеля у его носителя. Например, при пенетрантности 80% из 100 носителей клинические проявления будут примерно у 80. Не путай с экспрессивностью: она описывает степень выраженности симптомов.";
    if (q.includes("экспрессив")) return "Экспрессивность — это тяжесть или степень проявления признака. При одной и той же мутации у разных членов семьи симптомы могут быть лёгкими или тяжёлыми — это вариабельная экспрессивность.";
    if (q.includes("родослов")) return "Для анализа родословной смотри: есть ли вертикальная передача, болеют ли оба пола, есть ли передача отец–сын, появляются ли больные дети у здоровых родителей, передаёт ли признак мать всем детям. В редакторе родословных я применяю эти эвристики автоматически.";
    if (q.includes("пцр") || q.includes("pcr")) return "ПЦР нужна для амплификации выбранного фрагмента ДНК. В диагностике это позволяет получить достаточно копий целевой последовательности, чтобы выявить мутацию, провести электрофорез, секвенирование или другую детекцию.";
    if (q.includes("план")) return makePersonalPlan();
    return "Я могу объяснить тему, создать карточки или тест, но в этой MVP-версии отвечаю локально. Для настоящего ИИ подключите backend endpoint в функции callRealAI() и передавайте туда промпт вместе с rawText выбранного раздела.";
  }

  // Заготовка для реального API. В браузере лучше НЕ хранить ключ: сделайте backend /api/ai.
  async function callRealAI({ endpoint = "/api/ai", prompt, text, schema }) {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, text, schema })
    });
    if (!response.ok) throw new Error("AI API error");
    return response.json();
  }

  window.generateFlashcardsFromText = generateFlashcardsFromText;
  window.generateQuizFromText = generateQuizFromText;
  window.callRealAI = callRealAI;

  function generateAndSaveFlashcardsForSection(sectionId) {
    const section = data.sections.find(s => s.id === sectionId);
    if (!section) return;
    const cards = generateFlashcardsFromText(section.rawText || stripHtml(section.contentHtml), { source: section.title, sectionId: section.id });
    const valid = validateFlashcards(cards);
    data.flashcards.push(...valid);
    data.editHistory.push({ id: uid("hist"), entity: "flashcards", entityId: "bulk", action: "ai-generate", at: new Date().toISOString(), title: `Карточки из ${section.title}`, count: valid.length });
    saveData();
    toast(`Создано карточек: ${valid.length}. Их можно отредактировать в data.js или расширить редактором карточек.`);
    go("flashcards");
  }

  function generateAndSaveQuizForSection(sectionId) {
    const section = data.sections.find(s => s.id === sectionId);
    if (!section) return;
    const quiz = generateQuizFromText(section.rawText || stripHtml(section.contentHtml), { title: `Тест: ${section.title}`, sectionId: section.id, tags: section.tags || [] });
    data.quizzes.push(quiz);
    data.editHistory.push({ id: uid("hist"), entity: "quizzes", entityId: quiz.id, action: "ai-generate", at: new Date().toISOString(), title: quiz.title, count: quiz.questions.length });
    saveData();
    toast(`Создан тест: ${quiz.questions.length} вопросов`);
    go("quizzes");
  }

  function generateFlashcardsFromText(text, meta = {}) {
    const clean = normalizeSpaces(text).slice(0, 12000);
    const cards = [];
    const definitionPatterns = [
      /([А-ЯA-ZЁ][А-Яа-яA-Za-zЁё\-\s]{2,45})\s+[—–-]\s+это\s+([^.!?]{20,240})/g,
      /Под\s+([а-яА-ЯёЁ\-\s]{3,45})\s+понимают\s+([^.!?]{20,240})/gi,
      /([А-ЯA-ZЁ][А-Яа-яA-Za-zЁё\-\s]{2,45})\s+называют\s+([^.!?]{20,240})/g
    ];
    for (const re of definitionPatterns) {
      let match;
      while ((match = re.exec(clean)) && cards.length < 8) {
        const term = normalizeSpaces(match[1]).replace(/^Под\s+/i, "");
        const def = normalizeSpaces(match[2]);
        if (term.length > 2 && def.length > 15) {
          cards.push(makeCard(`Что такое ${term.toLowerCase()}?`, capitalize(def), `${term}: ${def}. Важно уметь отличать этот термин от близких понятий и приводить медицинский пример.`, meta));
        }
      }
    }
    const highYield = [
      ["пенетрант", "Чем пенетрантность отличается от экспрессивности?", "Пенетрантность — вероятность проявления аллеля; экспрессивность — степень выраженности признака."],
      ["Aa × Aa", "Какое расщепление даёт Aa × Aa?", "1AA : 2Aa : 1aa по генотипу; при полном доминировании 3:1 по фенотипу."],
      ["ПЦР", "Зачем используют ПЦР?", "Для амплификации целевого фрагмента ДНК."],
      ["кариотип", "Что показывает кариотипирование?", "Число и структуру хромосом."],
      ["митохондри", "Как передаётся митохондриальное наследование?", "От матери всем детям; отец обычно не передаёт мтДНК потомству."]
    ];
    for (const [needle, question, answer] of highYield) {
      if (clean.toLowerCase().includes(needle.toLowerCase()) && cards.length < 10) cards.push(makeCard(question, answer, `Карточка создана по ключевому фрагменту текста раздела: ${meta.source || "пользовательский материал"}.`, meta));
    }
    if (!cards.length) {
      const sentences = clean.split(/[.!?]\s+/).filter(s => s.length > 80).slice(0, 4);
      for (const sentence of sentences) cards.push(makeCard("Сформулируйте ключевую мысль фрагмента", sentence.slice(0, 160), sentence, meta));
    }
    return cards.slice(0, 10);
  }

  function makeCard(question, shortAnswer, explanation, meta) {
    return {
      id: uid("fc"),
      question,
      shortAnswer,
      explanation,
      source: meta.source || "ИИ‑генерация",
      sectionId: meta.sectionId || null,
      difficulty: inferDifficulty(question + " " + explanation),
      tags: unique([...(meta.tags || []), ...extractTags(question + " " + explanation)]).slice(0, 6),
      interval: 0,
      repetition: 0,
      ease: 2.5,
      due: null,
      generated: true,
      createdAt: new Date().toISOString()
    };
  }

  function validateFlashcards(cards) {
    return cards.filter(c => c.question && c.shortAnswer && c.explanation).map(c => ({ ...c, difficulty: Number(c.difficulty) || 2, tags: c.tags?.length ? c.tags : ["ИИ"] }));
  }

  function generateQuizFromText(text, meta = {}) {
    const cards = generateFlashcardsFromText(text, { source: meta.title || "раздел", sectionId: meta.sectionId, tags: meta.tags || [] });
    const questions = cards.slice(0, 5).map((card, index) => {
      if (index === 0) {
        return { id: uid("q"), type: "open", question: card.question, answer: card.shortAnswer, keywords: extractKeywords(card.shortAnswer), explanation: card.explanation };
      }
      const distractors = makeDistractors(card.shortAnswer);
      return { id: uid("q"), type: "single", question: card.question, options: shuffle([card.shortAnswer, ...distractors]).slice(0, 4), answer: card.shortAnswer, explanation: card.explanation };
    });
    questions.push({ id: uid("q"), type: "truefalse", question: "Пенетрантность и экспрессивность — это полностью одинаковые понятия.", answer: false, explanation: "Пенетрантность показывает вероятность проявления признака, а экспрессивность — степень его выраженности." });
    return { id: uid("quiz"), title: meta.title || "Сгенерированный тест", description: "Черновик теста, созданный локальным генератором. Перед использованием проверьте формулировки.", sectionIds: meta.sectionId ? [meta.sectionId] : [], tags: meta.tags || ["ИИ"], questions, generated: true, createdAt: new Date().toISOString() };
  }

  function makeDistractors(answer) {
    const bank = ["Случайное распределение хромосом в соматических клетках", "Метод окраски метафазных хромосом", "Передача признака только от отца к сыну", "Вариант нормы без клинического значения", "Отношение 9:3:3:1 при дигибридном скрещивании"];
    return bank.filter(x => normalizeText(x) !== normalizeText(answer)).slice(0, 3);
  }

  function inferDifficulty(text) {
    const t = normalizeText(text);
    if (["гетерогенность", "экспрессивность", "саузерн", "генотерап", "кариотип"].some(x => t.includes(x))) return 3;
    if (["пенетран", "x-сцеп", "митохонд", "эпистаз"].some(x => t.includes(x))) return 2;
    return 1;
  }

  function extractTags(text) {
    const keys = ["Мендель", "пенетрантность", "экспрессивность", "ПЦР", "кариотип", "X-сцепленное", "митохондриальное", "эпистаз", "полимерия", "гетерогенность", "ДНК"];
    const lower = normalizeText(text);
    return keys.filter(k => lower.includes(normalizeText(k)));
  }

  function extractKeywords(text) {
    return normalizeText(text).split(/\s+/).filter(w => w.length > 5).slice(0, 6);
  }

  function renderPedigree() {
    return `
      ${pageHead("Редактор родословных", "Минимальная интерактивная версия", "Добавляйте людей, указывайте пол и статус, связывайте родителей, детей и партнёров. Анализатор применяет базовые эвристики по типам наследования.")}
      <section class="card">
        <div class="pedigree-toolbar">
          <div class="form-row"><label>Имя</label><input id="pedName" value="${nextPedigreeName()}" /></div>
          <div class="form-row"><label>Пол</label><select id="pedSex"><option value="male">мужской</option><option value="female">женский</option><option value="unknown">неизвестно</option></select></div>
          <div class="form-row"><label>Статус</label><select id="pedStatus"><option value="healthy">здоров</option><option value="affected">болен</option><option value="carrier">носитель</option><option value="unknown">неизвестно</option></select></div>
          <div class="form-row"><label>Поколение</label><input id="pedGeneration" type="number" min="1" value="1" /></div>
          <button class="primary" id="addPersonBtn">Добавить</button>
          <button class="secondary" id="resetPedigreeBtn">Сброс</button>
        </div>
        <hr>
        <div class="grid two">
          <div class="form-row"><label>Связь родитель → ребёнок</label><div class="grid two">${personSelect("parentSelect")}${personSelect("childSelect")}</div><button class="secondary" id="addParentChildBtn">Добавить связь</button></div>
          <div class="form-row"><label>Брак/партнёрство</label><div class="grid two">${personSelect("partnerA")}${personSelect("partnerB")}</div><button class="secondary" id="addPartnerBtn">Добавить партнёрство</button></div>
        </div>
        <hr>
        <div class="pedigree-canvas">${renderPedigreeSvg()}</div>
        <div class="actions"><button class="primary" id="analyzePedigreeBtn">Предположить тип наследования</button></div>
        <div id="pedigreeAnalysis" class="feedback">${escapeHtml(analyzePedigree(runtime.pedigree))}</div>
      </section>
    `;
  }

  function personSelect(id) {
    return `<select id="${id}">${runtime.pedigree.persons.map(p => `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join("")}</select>`;
  }

  function nextPedigreeName() {
    const n = runtime.pedigree.persons.length + 1;
    return `P-${n}`;
  }

  function bindPedigreeEvents() {
    $("#addPersonBtn")?.addEventListener("click", () => {
      runtime.pedigree.persons.push({ id: uid("p"), name: $("#pedName").value.trim() || nextPedigreeName(), sex: $("#pedSex").value, status: $("#pedStatus").value, generation: Number($("#pedGeneration").value) || 1 });
      render();
    });
    $("#addParentChildBtn")?.addEventListener("click", () => {
      const parentId = $("#parentSelect").value;
      const childId = $("#childSelect").value;
      if (parentId === childId) return toast("Родитель и ребёнок не могут быть одним человеком");
      runtime.pedigree.parentChild.push({ parentId, childId });
      render();
    });
    $("#addPartnerBtn")?.addEventListener("click", () => {
      const a = $("#partnerA").value;
      const b = $("#partnerB").value;
      if (a === b) return toast("Выберите двух разных людей");
      runtime.pedigree.partners.push({ a, b });
      render();
    });
    $("#resetPedigreeBtn")?.addEventListener("click", () => { runtime.pedigree = defaultPedigree(); render(); });
    $("#analyzePedigreeBtn")?.addEventListener("click", () => { $("#pedigreeAnalysis").textContent = analyzePedigree(runtime.pedigree); });
  }

  function renderPedigreeSvg() {
    const persons = runtime.pedigree.persons;
    const byGen = groupBy(persons, p => p.generation || 1);
    const positions = new Map();
    let height = 140;
    const width = 960;
    Object.entries(byGen).forEach(([gen, ps]) => {
      const y = Number(gen) * 105 - 55;
      height = Math.max(height, y + 80);
      ps.forEach((p, i) => {
        const gap = width / (ps.length + 1);
        positions.set(p.id, { x: gap * (i + 1), y });
      });
    });
    const partnerLines = runtime.pedigree.partners.map(rel => {
      const a = positions.get(rel.a), b = positions.get(rel.b);
      if (!a || !b) return "";
      return `<line x1="${a.x + 22}" y1="${a.y}" x2="${b.x - 22}" y2="${b.y}" stroke="currentColor" stroke-width="2"/>`;
    }).join("");
    const childLines = runtime.pedigree.parentChild.map(rel => {
      const a = positions.get(rel.parentId), b = positions.get(rel.childId);
      if (!a || !b) return "";
      return `<line x1="${a.x}" y1="${a.y + 24}" x2="${b.x}" y2="${b.y - 24}" stroke="currentColor" stroke-width="1.6" opacity="0.75"/>`;
    }).join("");
    const nodes = persons.map(p => {
      const pos = positions.get(p.id);
      const shape = pedigreeShape(p, pos.x, pos.y);
      return `<g class="pedigree-person">${shape}<text x="${pos.x}" y="${pos.y + 48}" text-anchor="middle">${escapeHtml(p.name)}</text></g>`;
    }).join("");
    return `<svg viewBox="0 0 ${width} ${height}" width="100%" height="${height}" role="img" aria-label="Родословная">${partnerLines}${childLines}${nodes}</svg>`;
  }

  function pedigreeShape(p, x, y) {
    const cls = `status-${p.status}`;
    if (p.sex === "female") return `<circle class="${cls}" cx="${x}" cy="${y}" r="23" stroke="currentColor" stroke-width="2"/>${p.status === "carrier" ? `<circle cx="${x}" cy="${y}" r="9" fill="currentColor" opacity=".35"/>` : ""}`;
    if (p.sex === "male") return `<rect class="${cls}" x="${x - 23}" y="${y - 23}" width="46" height="46" stroke="currentColor" stroke-width="2" rx="4"/>${p.status === "carrier" ? `<circle cx="${x}" cy="${y}" r="9" fill="currentColor" opacity=".35"/>` : ""}`;
    return `<polygon class="${cls}" points="${x},${y - 25} ${x + 25},${y} ${x},${y + 25} ${x - 25},${y}" stroke="currentColor" stroke-width="2"/>`;
  }

  function analyzePedigree(pedigree) {
    const persons = pedigree.persons;
    const affected = persons.filter(p => p.status === "affected");
    if (!affected.length) return "Недостаточно данных: нет больных членов родословной.";
    const affectedMen = affected.filter(p => p.sex === "male").length;
    const affectedWomen = affected.filter(p => p.sex === "female").length;
    const fatherSon = pedigree.parentChild.some(rel => {
      const parent = persons.find(p => p.id === rel.parentId);
      const child = persons.find(p => p.id === rel.childId);
      return parent?.sex === "male" && child?.sex === "male" && parent.status === "affected" && child.status === "affected";
    });
    const affectedInEveryGeneration = unique(affected.map(p => p.generation)).length >= Math.min(unique(persons.map(p => p.generation)).length, 2);
    const healthyParentsAffectedChild = pedigree.parentChild.some(rel => {
      const child = persons.find(p => p.id === rel.childId);
      if (child?.status !== "affected") return false;
      const parents = pedigree.parentChild.filter(r => r.childId === child.id).map(r => persons.find(p => p.id === r.parentId)).filter(Boolean);
      return parents.length >= 2 && parents.every(p => p.status === "healthy" || p.status === "carrier");
    });
    if (affectedMen > 0 && affectedWomen === 0 && fatherSon) return "Вероятнее Y-сцепленное наследование: болеют мужчины и есть передача отец → сын. Проверьте, все ли сыновья больного отца поражены.";
    if (affectedMen > affectedWomen * 2 && !fatherSon) return "Вероятнее X-сцепленное рецессивное наследование: больше больных мужчин и нет передачи отец → сын.";
    if (affectedInEveryGeneration && affectedMen && affectedWomen) return "Вероятнее аутосомно-доминантное наследование: вертикальная передача и поражение обоих полов. Учтите неполную пенетрантность и de novo мутации.";
    if (healthyParentsAffectedChild) return "Вероятнее аутосомно-рецессивное наследование: больной ребёнок появляется у клинически здоровых родителей/носителей.";
    const affectedMothersAllChildren = affected.some(m => m.sex === "female" && pedigree.parentChild.filter(r => r.parentId === m.id).length > 0 && pedigree.parentChild.filter(r => r.parentId === m.id).every(r => persons.find(p => p.id === r.childId)?.status === "affected"));
    if (affectedMothersAllChildren) return "Возможен митохондриальный тип: поражённая мать передаёт признак всем детям. Проверьте отсутствие передачи от отцов.";
    return "Тип наследования неочевиден. Добавьте больше поколений, статусы родителей, пол больных и данные о носительстве.";
  }

  function renderKaryotype() {
    const selected = data.karyotypes.find(k => k.id === runtime.selectedKaryotypeId) || data.karyotypes[0];
    return `
      ${pageHead("Редактор / симулятор кариотипов", "Нормальные и патологические наборы хромосом", "Минимальная версия визуализирует 22 пары аутосом и гоносомы, подсвечивает трисомии, моносомии и делеции.")}
      <section class="grid two">
        <article class="card">
          <h2>Выберите кариотип</h2>
          <div class="form-grid">
            <div class="form-row"><label>Сценарий</label><select id="karyotypeSelect">${data.karyotypes.map(k => `<option value="${k.id}" ${k.id === selected.id ? "selected" : ""}>${escapeHtml(k.label)} — ${escapeHtml(k.description)}</option>`).join("")}</select></div>
          </div>
          <hr>
          <h3>${escapeHtml(selected.label)}</h3>
          <p>${escapeHtml(selected.description)}</p>
          ${selected.diseaseId ? `<button class="secondary" data-open-section="${data.diseases.find(d => d.id === selected.diseaseId)?.sectionId || "chromosomal-diseases"}">Открыть связанный раздел</button>` : ""}
        </article>
        <article class="card">
          <h2>Визуализация</h2>
          <div class="karyo-canvas"><div class="karyo-grid">${renderChromosomeGrid(selected)}</div></div>
        </article>
      </section>
    `;
  }

  function bindKaryotypeEvents() {
    $("#karyotypeSelect")?.addEventListener("change", e => { runtime.selectedKaryotypeId = e.target.value; render(); });
  }

  function renderChromosomeGrid(karyotype) {
    const anomaly = (chromosome, type) => karyotype.anomalies?.some(a => String(a.chromosome) === String(chromosome) && a.type === type);
    const cards = [];
    for (let i = 1; i <= 22; i++) {
      const extra = anomaly(i, "trisomy") || anomaly(String(i), "trisomy");
      const deleted = karyotype.anomalies?.some(a => String(a.chromosome).startsWith(String(i)) && a.type === "deletion");
      cards.push(`<div class="chromosome-card"><div class="chromosome-pair"><span class="chromosome ${deleted ? "deleted" : ""}"></span><span class="chromosome ${deleted ? "deleted" : ""}"></span>${extra ? `<span class="chromosome extra"></span>` : ""}</div><strong>${i}</strong></div>`);
    }
    const sex = karyotype.label.includes("XXY") ? ["X", "X", "Y"] : karyotype.label.includes("XY") ? ["X", "Y"] : karyotype.label.includes("45,X") ? ["X", "missing"] : ["X", "X"];
    cards.push(`<div class="chromosome-card"><div class="chromosome-pair">${sex.map(s => `<span class="chromosome ${s === "missing" ? "missing" : s === "Y" ? "extra" : ""}"></span>`).join("")}</div><strong>пол.</strong></div>`);
    return cards.join("");
  }

  function renderProgress() {
    const stats = getStats();
    const quizSummaries = Object.entries(data.userProgress.quizzes || {});
    return `
      ${pageHead("Прогресс пользователя", "Статистика localStorage", "Прогресс чтения, карточек, тестов и история правок хранятся локально в браузере.")}
      <section class="grid four">
        <div class="card stat"><strong>${stats.progress}%</strong><span>прочитано</span></div>
        <div class="card stat"><strong>${dueFlashcards().length}</strong><span>карточек сегодня</span></div>
        <div class="card stat"><strong>${quizSummaries.length}</strong><span>тестов начато</span></div>
        <div class="card stat"><strong>${(data.userProgress.weakTags || []).length}</strong><span>слабых тегов</span></div>
      </section>
      <section class="grid two" style="margin-top:18px;">
        <article class="card">
          <h2>Слабые темы</h2>
          ${(data.userProgress.weakTags || []).length ? `<div class="chips">${data.userProgress.weakTags.map(t => `<span class="chip">${escapeHtml(t)}</span>`).join("")}</div><p>${makePersonalPlan()}</p>` : `<p class="muted">Пока нет статистики ошибок. Пройдите тесты, чтобы появились рекомендации.</p>`}
        </article>
        <article class="card">
          <h2>История изменений</h2>
          ${data.editHistory.length ? data.editHistory.slice().reverse().slice(0, 12).map(h => `<div class="card compact" style="margin-bottom:8px;"><strong>${escapeHtml(h.action)}</strong> — ${escapeHtml(h.title || h.entity)}<br><span class="small">${new Date(h.at).toLocaleString("ru-RU")}</span></div>`).join("") : `<p class="muted">Пока нет изменений.</p>`}
        </article>
      </section>
    `;
  }

  function makePersonalPlan() {
    const weak = data.userProgress.weakTags || [];
    if (!weak.length) return "Индивидуальный план появится после тестов. Сейчас начните с разделов «Типы наследования», «ДНК‑диагностика» и 10 карточек в день.";
    return `Индивидуальный план: 1) перечитать разделы с тегами ${weak.slice(0, 5).join(", ")}; 2) сгенерировать по ним 10 карточек; 3) пройти короткий тест; 4) вернуться к ошибочным вопросам через 24 часа.`;
  }

  function renderSearch() {
    const q = runtime.searchQuery || $("#globalSearch")?.value || "";
    const hits = searchAll(q);
    return `
      ${pageHead("Поиск", q ? `Запрос: ${escapeHtml(q)}` : "Введите запрос", "Поиск идёт по разделам, глоссарию, болезням, карточкам и пользовательским материалам.")}
      <section class="search-results">
        ${q ? hits.map(hit => `
          <article class="card search-hit">
            <span class="badge primary-badge">${escapeHtml(hit.type)}</span>
            <h3 style="margin-top:12px;">${highlight(hit.title, q)}</h3>
            <p>${highlight(hit.text, q)}</p>
            ${hit.sectionId ? `<button class="secondary" data-open-section="${hit.sectionId}">Открыть раздел</button>` : ""}
          </article>
        `).join("") || `<div class="empty">Ничего не найдено.</div>` : `<div class="empty">Начните вводить запрос в верхней строке.</div>`}
      </section>
    `;
  }

  function searchAll(query) {
    const q = normalizeText(query);
    if (!q) return [];
    const hits = [];
    for (const s of data.sections) {
      const hay = normalizeText(`${s.title} ${s.summary} ${s.rawText} ${stripHtml(s.contentHtml)} ${s.tags?.join(" ")}`);
      if (hay.includes(q)) hits.push({ type: "раздел", title: s.title, text: s.summary || s.rawText.slice(0, 220), sectionId: s.id });
    }
    for (const t of data.glossaryTerms) {
      const hay = normalizeText(`${t.term} ${t.definition} ${t.full}`);
      if (hay.includes(q)) hits.push({ type: "термин", title: t.term, text: `${t.definition} ${t.full || ""}`, sectionId: t.sectionId });
    }
    for (const d of data.diseases) {
      const hay = normalizeText(`${d.name} ${d.gene} ${d.symptoms.join(" ")} ${d.diagnostics.join(" ")} ${d.tags.join(" ")}`);
      if (hay.includes(q)) hits.push({ type: "болезнь", title: d.name, text: `${d.gene}. ${d.symptoms.join(", ")}`, sectionId: d.sectionId });
    }
    for (const c of data.flashcards) {
      const hay = normalizeText(`${c.question} ${c.shortAnswer} ${c.explanation} ${c.tags.join(" ")}`);
      if (hay.includes(q)) hits.push({ type: "карточка", title: c.question, text: c.shortAnswer, sectionId: c.sectionId });
    }
    for (const m of data.userMaterials) {
      const hay = normalizeText(`${m.title} ${m.text} ${m.tags.join(" ")}`);
      if (hay.includes(q)) hits.push({ type: "материал пользователя", title: m.title, text: m.text.slice(0, 260) });
    }
    return hits.slice(0, 40);
  }

  function markSectionRead(sectionId) {
    data.userProgress.readSections = unique([...(data.userProgress.readSections || []), sectionId]);
    saveData();
  }

  function saveAsSectionFromMaterial(material) {
    const section = {
      id: uid("section"),
      topicId: "part-1",
      title: material.title,
      order: data.sections.length + 1,
      type: "user",
      source: { manual: "user", pages: "" },
      tags: material.tags,
      summary: material.text.slice(0, 180),
      contentHtml: `<p>${escapeHtml(material.text).replace(/\n\n+/g, "</p><p>").replace(/\n/g, "<br>")}</p>`,
      rawText: material.text,
      userCreated: true
    };
    data.sections.push(section);
    saveData();
    return section;
  }

  function sourceLabel(source = {}) {
    if (!source.manual) return "без источника";
    const manual = source.manual === "manual-1" ? "Ч.1" : source.manual === "manual-2" ? "Ч.2" : source.manual === "manual-3" ? "Ч.3" : "польз.";
    return source.pages ? `${manual}, с. ${source.pages}` : manual;
  }

  function pageHead(title, eyebrow, lead) {
    return `
      <header class="page-head">
        <div>
          <p class="eyebrow">${escapeHtml(eyebrow)}</p>
          <h1>${escapeHtml(title)}</h1>
          <p class="lead">${escapeHtml(lead)}</p>
        </div>
      </header>
    `;
  }

  function groupBy(items, fn) {
    return items.reduce((acc, item) => {
      const key = fn(item);
      acc[key] ||= [];
      acc[key].push(item);
      return acc;
    }, {});
  }

  function unique(arr) {
    return [...new Set(arr.filter(x => x !== undefined && x !== null && x !== ""))];
  }

  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function arraysEqual(a, b) {
    return a.length === b.length && a.every((x, i) => x === b[i]);
  }

  function normalizeText(text) {
    return String(text || "").toLowerCase().replace(/ё/g, "е").replace(/\s+/g, " ").trim();
  }

  function normalizeSpaces(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function stripHtml(html) {
    const div = document.createElement("div");
    div.innerHTML = html || "";
    return div.textContent || "";
  }

  function capitalize(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function escapeAttr(value) {
    return escapeHtml(value).replaceAll("`", "&#096;");
  }

  function highlight(text, query) {
    const safe = escapeHtml(String(text || ""));
    const q = escapeHtml(String(query || "").trim());
    if (!q) return safe;
    try {
      const re = new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
      return safe.replace(re, "<mark>$1</mark>");
    } catch {
      return safe;
    }
  }

  function formatMessage(text) {
    return escapeHtml(text).replace(/\n/g, "<br>");
  }

  function debounce(fn, delay) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), delay);
    };
  }

  function toast(message) {
    const el = $("#toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => el.classList.remove("show"), 2800);
  }

  document.addEventListener("click", (event) => {
    const diseaseTab = event.target.closest("[data-disease-tab]");
    if (diseaseTab) {
      runtime.selectedDiseaseCategory = diseaseTab.dataset.diseaseTab;
      render();
    }
  });

  init();
})();
